

    /*
     * FastIRQ2
     *
     * Copyright (c) 2019, Dipl. Phys. Helmut Weber.
     * All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without
     * modification, are permitted provided that the following conditions
     * are met:
     * 1. Redistributions of source code must retain the above copyright
     *    notice, this list of conditions and the following disclaimer.
     * 2. Redistributions in binary form must reproduce the above copyright
     *    notice, this list of conditions and the following disclaimer in the
     *    documentation and/or other materials provided with the distribution.
     * 3. Neither the name of the Institute nor the names of its contributors
     *    may be used to endorse or promote products derived from this software
     *    without specific prior written permission.
     *
     * THIS SOFTWARE IS PROVIDED BY Helmut Weber ``AS IS'' AND
     * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
     * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
     * ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE
     * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
     * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
     * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
     * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
     * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
     * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
     * SUCH DAMAGE.
     *
     * This file is part of the CoopOS library.
     *
     * Author: Helmut Weber <Dph.HelmutWeber@web.de>
     *
     * $Id: Task.h,v 1.1 2019/04/02  helmut Exp $ IDF 3.1
     * $Id: Task.h,v 2.0 2019/04/02  helmut Exp $ IDF 4.1
     */
     
#pragma GCC optimize ("O3")
     
#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "soc/timer_group_struct.h"
#include "soc/timer_group_reg.h"
#include "freertos/portmacro.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_task_wdt.h"
#include <soc/rtc.h>
#include "esp_system.h"
#include "esp_event.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "driver/timer.h"
#include "esp32/rom/uart.h"
#include "esp_task_wdt.h"



#define GPIO_Set(x)             REG_WRITE(GPIO_OUT_W1TS_REG, 1<<x) 
#define GPIO_Clear(x)           REG_WRITE(GPIO_OUT_W1TC_REG, 1<<x) 
#define GPIO_IN_Read(x)         REG_READ(GPIO_IN_REG) & (1<<x) 
#define GPIO_IN_ReadAll()       REG_READ(GPIO_IN_REG) 
#define pinMode(a,b)            gpio_set_direction(a, b);     

// measure the superloop time in clock-cycles
//#define LOOPTIME
     

    #define STACK_SIZE 4096

     
    #define PinA GPIO_NUM_18  // output          shortcut   > _____
    #define PinB GPIO_NUM_19  // input                      < _____|----- scope ch 1
    #define PinC GPIO_NUM_21  // output                                   scope ch 2
     
    TaskHandle_t xHandle1 ;
    TaskHandle_t xHandle2 ;
    TaskHandle_t TaskA;  
     
    volatile int Irqs=0;
    volatile int Irqs2=0;
    volatile int IrqsPerSecond=0;
    volatile int IrqsPerSecond2=0;
    int IrqErrors=0;
    
    volatile uint32_t maxDiff, minDiff=99999;
  
    char http_bf[2000];
     
       
       
    /*
     * Macro to check the outputs of TWDT functions and trigger an abort if an
     * incorrect code is returned.
     */
    #define CHECK_ERROR_CODE(returned, expected) ({                        \
                if(returned != expected){                                  \
                    printf("TWDT ERROR\n");                                \
                    abort();                                               \
                }                                                          \
    })
     
     
    
    inline uint32_t IRAM_ATTR clocks()
    {
    uint32_t ccount;
    asm volatile ( "rsr %0, ccount" : "=a" (ccount) );
    return ccount;
    }
    
    
    

    uint64_t millis() {
      return esp_timer_get_time()/1000l;
    }

    uint64_t micros() {
      return esp_timer_get_time();
    }

     
    void IRAM_ATTR delayMicroseconds(uint32_t us)
    {
      if(us){
        uint32_t m = micros();
        while( (micros() - m ) < us ){
          asm(" nop");
        }
      }
    }
    
    
    void inline delayClocks(uint32_t clks)
    {
        uint32_t c = clocks();
        while( (clocks() - c ) < clks ){
          asm(" nop");
        }
      
    }
     
     

    /*------------------------------------------------------------------
    Core1:
    This task runs on core 1 without any interruption:
    No taskswitch
    No other interrupts
    It does the pinchange "interrupt" detection by polling.
    This is all the core 1 is doing.
    Maybe a waste - but superfast!
    It detects a pinchange within 134 ns and is able to react.
    ------------------------------------------------------------------*/
     
    void IRAM_ATTR Core1( void* p) {
    
       printf("Start Core 1\n");
       vTaskDelay(1000);
       
       // I do not want an RTOS-Tick here
       portDISABLE_INTERRUPTS();  // YEAH
       
       register int level, oldLevel=0;
       uint32_t start=clocks();
       uint32_t start2, diff;  
 #ifdef LOOPTIME
       while(1) {                                                       // the superloop
         level=GPIO_IN_Read(PinB);       
        
         if (level != oldLevel) {
            GPIO_Set(PinC);
            GPIO_Clear(PinC);
            Irqs++;
            oldLevel=level;
         }
         
         start2=clocks();
         diff=start2-start;
         start=start2;
         if (diff>maxDiff) maxDiff=diff;
         if (diff<minDiff) minDiff=diff;
         
       }
#else
       
       while(1) {                                                       // the superloop
         level=GPIO_IN_Read(PinB);                                      
         
         if (level != oldLevel) {
            GPIO_Set(PinC);
            GPIO_Clear(PinC);
            Irqs++;
         }
         oldLevel=level;
       }
#endif
       
       
    }
     

   
     
     
    // Function that creates the superloop Core1 to be pinned at Core 1
    void StartCore1( void )
    {
        
        xTaskCreatePinnedToCore(
                      Core1,       // Function that implements the task.
                      "Core1",          // Text name for the task.
                      STACK_SIZE,      // Stack size in bytes, not words.
                      ( void * ) 1,    // Parameter passed into the task.
                      tskIDLE_PRIORITY+2,
                      &TaskA,
                      1);              // Core 1
    }
     
     
    /*------------------------------------------------------------------
    RTOS1:
    This task prints the counted "pin change interrupts" to terminal
    once a second and saves the value for the WebServer
    ------------------------------------------------------------------*/
    void RTOS_1(void *p) {
int cnt=0;
       //esp_task_wdt_deinit();
       while(1) {
        //esp_task_wdt_reset();
        cnt++;
        printf("RTOS-1 Irqs/s   sent / received: %u / %u\n", Irqs2, Irqs);                            // demo for full function
        IrqsPerSecond=Irqs;
        IrqsPerSecond2=Irqs2;
        Irqs2=0;
        Irqs=0;
        taskYIELD();
        if (cnt>3)                                                      // wait to stabilize 
           if (IrqsPerSecond != IrqsPerSecond2) IrqErrors++;
        //sprintf(http_bf,"Interrupts per second: %d",IrqsPerSecond);
        
#ifdef LOOPTIME
        sprintf(http_bf,\
              "<head>\
                  <style>\
                      h1 { color:red; font-size:64px; }\
                      p  {color:green; font-size:48px; text-align:center}\
                      a  {color:green; font-size:48px; text-align:center}\
                  </style> \
                  <meta http-equiv=\"refresh\" content=\"2\">\
              </head>\
              <body>\
                <br>\
                <a href=\"http://HelmutWeber.de\">\
                <button style=\"color:blue; font-size:20px; margin-top:20px; margin-left:80px; border-radius:8px;  title:\"click here\" \">German Version at <br>http://HelmutWeber.de</button>\
                </a>\
                <br>\
                <center>\
                  <h1>ESP32_RTOS_FastIrq</h1>\
                  <br>\
                  <p>External IRQs sent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; per Second [%u]</p>\
                  <p>External IRQs received per Second [%u]</p>\
                  <p>Irq Errors  [%u] us</p>\
                  <p>Count  [%u] times</p>\
                  <p>Looptime max.  [%2.2f] us</p>\
                  <p>Looptime min.  [%2.2f] us</p>\
                  <p>github: MacLeod-D</p>\
                </center>\                
              </body>",IrqsPerSecond2, IrqsPerSecond, IrqErrors, cnt, (float)maxDiff/(float)240, (float)minDiff/(float)240   );
              maxDiff=0; minDiff=9999;
#else
        sprintf(http_bf,\
              "<head>\
                  <style>\
                      h1 { color:red; font-size:64px; }\
                      p  {color:green; font-size:48px; text-align:center}\
                      a  {color:green; font-size:48px; text-align:center}\
                  </style> \
                  <meta http-equiv=\"refresh\" content=\"2\">\
              </head>\
              <body>\
                <br>\
                <a href=\"http://HelmutWeber.de\">\
                <button style=\"color:blue; font-size:20px; margin-top:20px; margin-left:80px; border-radius:8px;  title:\"click here\" \">German Version at <br>http://HelmutWeber.de</button>\
                </a>\
                <br>\
                <center>\
                  <h1>ESP32_RTOS_FastIrq</h1>\
                  <br>\
                  <p>External IRQs sent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; per Second [%u]</p>\
                  <p>External IRQs received per Second [%u]</p>\
                  <p>Irq Errors  [%u] us</p>\
                  <p>Count  [%u] times</p>\
                  <p>github: MacLeod-D</p>\
                </center>\                
              </body>",IrqsPerSecond2, IrqsPerSecond, IrqErrors, cnt );
              
#endif
    
        vTaskDelay(1000);
      }
    }
     
     

    /*------------------------------------------------------------------
    RTOS2:
    This task creates the signal (~300ns LOW, ~300ns HIGH) as a
    square wave at PinA(18).
    This PinA is connected to PinB(19) where pin changes are detected.
    Of cause you may feed pulses at PinB(19) from an external source!
    
    This task has no vTaskDelay - but it gets interrupted, when the
    timeslice of 1 ms is over.
    And then it can be interrupted for about 4ms - the time for the
    WiFi - because it is running on core 0.
    With an external IRQ source you do NOT have these interruptions!
    Core 1 is never interrupted at all head
    * !
    ------------------------------------------------------------------*/
     
    portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
     
    void RTOS_2(void *p) {
#ifdef LOOPTIME       
      while(1) {
        portDISABLE_INTERRUPTS();
        GPIO_Set(PinA);      // + 30 ns
        Irqs2++;
        delayClocks(50);                                                // 60 of 240 is  1/4 µs = 250 ns
        GPIO_Clear(PinA);    // + 30 ns
        Irqs2++;
        delayClocks(50);
        portENABLE_INTERRUPTS();
      }
      
#else
      while(1) {                                                        // gives 116 ns HIGH pulses, repeated evey 528 ns (== 2 Interrupts)
        portDISABLE_INTERRUPTS();                                           
        GPIO_Set(PinA);      // + 30 ns
        Irqs2++;
        delayClocks(40);                                                // 60 of 240 is  1/4 µs = 250 ns
        GPIO_Clear(PinA);    // + 30 ns
        Irqs2++;
        delayClocks(40);
        portENABLE_INTERRUPTS();
      }
#endif

      
    } 
    
    
    
    
// This WebServer is modified from IDF-Examples ../protocols/http_server/simple
//-----------------------------------------------------------------------------//
    
    
    
/* Simple HTTP Server Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/

#include <esp_wifi.h>
#include <esp_event.h>
#include <esp_log.h>
#include <esp_system.h>
#include <nvs_flash.h>
#include <sys/param.h>
#include "nvs_flash.h"
#include "esp_netif.h"
#include "esp_eth.h"
#include "protocol_examples_common.h"

#include <esp_http_server.h>



/* A simple example that demonstrates how to create GET and POST
 * handlers for the web server.
 */

static const char *TAG = "example";

/* An HTTP GET handler */
static esp_err_t info_get_handler(httpd_req_t *req)
{
    char*  buf;
    size_t buf_len;

    /* Get header value string length and allocate memory for length + 1,
     * extra byte for null termination */
    buf_len = httpd_req_get_hdr_value_len(req, "Host") + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        /* Copy null terminated value string into buffer */
        if (httpd_req_get_hdr_value_str(req, "Host", buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found header => Host: %s", buf);
        }
        free(buf);
    }

    buf_len = httpd_req_get_hdr_value_len(req, "Test-Header-2") + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (httpd_req_get_hdr_value_str(req, "Test-Header-2", buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found header => Test-Header-2: %s", buf);
        }
        free(buf);
    }

    buf_len = httpd_req_get_hdr_value_len(req, "Test-Header-1") + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (httpd_req_get_hdr_value_str(req, "Test-Header-1", buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found header => Test-Header-1: %s", buf);
        }
        free(buf);
    }

    /* Read URL query string length and allocate memory for length + 1,
     * extra byte for null termination */
    buf_len = httpd_req_get_url_query_len(req) + 1;
    if (buf_len > 1) {
        buf = malloc(buf_len);
        if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
            ESP_LOGI(TAG, "Found URL query => %s", buf);
            char param[32];
            /* Get value of expected key from query string */
            if (httpd_query_key_value(buf, "query1", param, sizeof(param)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => query1=%s", param);
            }
            if (httpd_query_key_value(buf, "query3", param, sizeof(param)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => query3=%s", param);
            }
            if (httpd_query_key_value(buf, "query2", param, sizeof(param)) == ESP_OK) {
                ESP_LOGI(TAG, "Found URL query parameter => query2=%s", param);
            }
        }
        free(buf);
    }

    /* Set some custom headers */
    httpd_resp_set_hdr(req, "Custom-Header-1", "Custom-Value-1");
    httpd_resp_set_hdr(req, "Custom-Header-2", "Custom-Value-2");

    /* Send response with custom headers and body set as the
     * string passed in user context*/
    const char* resp_str = (const char*) req->user_ctx;
    httpd_resp_send(req, resp_str, strlen(resp_str));

    /* After sending the HTTP response the old HTTP request
     * headers are lost. Check if HTTP request headers can be read now. */
    if (httpd_req_get_hdr_value_len(req, "Host") == 0) {
        ESP_LOGI(TAG, "Request headers lost");
    }
    return ESP_OK;
}




static const httpd_uri_t info = {
    .uri       = "/info",
    .method    = HTTP_GET,
    .handler   = info_get_handler,
    /* Let's pass response string in user
     * context to demonstrate it's usage */
    .user_ctx  = http_bf
    //.user_ctx = "Hello"
};

/* An HTTP POST handler */
static esp_err_t echo_post_handler(httpd_req_t *req)
{
    char buf[100];
    int ret, remaining = req->content_len;

    while (remaining > 0) {
        /* Read the data for the request */
        if ((ret = httpd_req_recv(req, buf,
                        MIN(remaining, sizeof(buf)))) <= 0) {
            if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
                /* Retry receiving if timeout occurred */
                continue;
            }
            return ESP_FAIL;
        }

        /* Send back the same data */
        httpd_resp_send_chunk(req, buf, ret);
        remaining -= ret;

        /* Log data received */
        ESP_LOGI(TAG, "=========== RECEIVED DATA ==========");
        ESP_LOGI(TAG, "%.*s", ret, buf);
        ESP_LOGI(TAG, "====================================");
    }

    // End response
    httpd_resp_send_chunk(req, NULL, 0);
    return ESP_OK;
}

static const httpd_uri_t echo = {
    .uri       = "/echo",
    .method    = HTTP_POST,
    .handler   = echo_post_handler,
    .user_ctx  = NULL
};

/* This handler allows the custom error handling functionality to be
 * tested from client side. For that, when a PUT request 0 is sent to
 * URI /ctrl, the /info and /echo URIs are unregistered and following
 * custom error handler http_404_error_handler() is registered.
 * Afterwards, when /info or /echo is requested, this custom error
 * handler is invoked which, after sending an error message to client,
 * either closes the underlying socket (when requested URI is /echo)
 * or keeps it open (when requested URI is /info). This allows the
 * client to infer if the custom error handler is functioning as expected
 * by observing the socket state.
 */
esp_err_t http_404_error_handler(httpd_req_t *req, httpd_err_code_t err)
{
    if (strcmp("/info", req->uri) == 0) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "/info URI is not available");
        /* Return ESP_OK to keep underlying socket open */
        return ESP_OK;
    } else if (strcmp("/echo", req->uri) == 0) {
        httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "/echo URI is not available");
        /* Return ESP_FAIL to close underlying socket */
        return ESP_FAIL;
    }
    /* For any other URI send 404 and close socket */
    httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Some 404 error message");
    return ESP_FAIL;
}

/* An HTTP PUT handler. This demonstrates realtime
 * registration and deregistration of URI handlers
 */
static esp_err_t ctrl_put_handler(httpd_req_t *req)
{
    char buf;
    int ret;

    if ((ret = httpd_req_recv(req, &buf, 1)) <= 0) {
        if (ret == HTTPD_SOCK_ERR_TIMEOUT) {
            httpd_resp_send_408(req);
        }
        return ESP_FAIL;
    }

    if (buf == '0') {
        /* URI handlers can be unregistered using the uri string */
        ESP_LOGI(TAG, "Unregistering /info and /echo URIs");
        httpd_unregister_uri(req->handle, "/info");
        httpd_unregister_uri(req->handle, "/echo");
        /* Register the custom error handler */
        httpd_register_err_handler(req->handle, HTTPD_404_NOT_FOUND, http_404_error_handler);
    }
    else {
        ESP_LOGI(TAG, "Registering /info and /echo URIs");
        httpd_register_uri_handler(req->handle, &info);
        httpd_register_uri_handler(req->handle, &echo);
        /* Unregister custom error handler */
        httpd_register_err_handler(req->handle, HTTPD_404_NOT_FOUND, NULL);
    }

    /* Respond with empty body */
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}

static const httpd_uri_t ctrl = {
    .uri       = "/ctrl",
    .method    = HTTP_PUT,
    .handler   = ctrl_put_handler,
    .user_ctx  = NULL
};

static httpd_handle_t start_webserver(void)
{
    httpd_handle_t server = NULL;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();

    // Start the httpd server
    ESP_LOGI(TAG, "Starting server on port: '%d'", config.server_port);
    if (httpd_start(&server, &config) == ESP_OK) {
        // Set URI handlers
        ESP_LOGI(TAG, "Registering URI handlers");
        httpd_register_uri_handler(server, &info);
        httpd_register_uri_handler(server, &echo);
        httpd_register_uri_handler(server, &ctrl);
        return server;
    }

    ESP_LOGI(TAG, "Error starting server!");
    return NULL;
}

static void stop_webserver(httpd_handle_t server)
{
    // Stop the httpd server
    httpd_stop(server);
}

static void disconnect_handler(void* arg, esp_event_base_t event_base, 
                               int32_t event_id, void* event_data)
{
    httpd_handle_t* server = (httpd_handle_t*) arg;
    if (*server) {
        ESP_LOGI(TAG, "Stopping webserver");
        stop_webserver(*server);
        *server = NULL;
    }
}

static void connect_handler(void* arg, esp_event_base_t event_base, 
                            int32_t event_id, void* event_data)
{
    httpd_handle_t* server = (httpd_handle_t*) arg;
    if (*server == NULL) {
        ESP_LOGI(TAG, "Starting webserver");
        *server = start_webserver();
    }
}
    
    
// WebServer END
//-----------------------------------------------------------------------------//
    
    
    
    
    
    
     
    
    void app_main(void)
    {
        
        
        
// Init:        
// This WebServer is modified from IDF-Examples ../protocols/http_server/simple
//----------------------------------------------------------------------------//
        
            static httpd_handle_t server = NULL;

            ESP_ERROR_CHECK(nvs_flash_init());
            esp_netif_init();
            ESP_ERROR_CHECK(esp_event_loop_create_default());

            /* This helper function configures Wi-Fi or Ethernet, as selected in menuconfig.
             * Read "Establishing Wi-Fi or Ethernet Connection" section in
             * examples/protocols/README.md for more information about this function.
             */
            ESP_ERROR_CHECK(example_connect());

            /* Register event handlers to stop the server when Wi-Fi or Ethernet is disconnected,
             * and re-start it upon connection.
             */
        #ifdef CONFIG_EXAMPLE_CONNECT_WIFI
            ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &connect_handler, &server));
            ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, WIFI_EVENT_STA_DISCONNECTED, &disconnect_handler, &server));
        #endif // CONFIG_EXAMPLE_CONNECT_WIFI
        #ifdef CONFIG_EXAMPLE_CONNECT_ETHERNET
            ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_ETH_GOT_IP, &connect_handler, &server));
            ESP_ERROR_CHECK(esp_event_handler_register(ETH_EVENT, ETHERNET_EVENT_DISCONNECTED, &disconnect_handler, &server));
        #endif // CONFIG_EXAMPLE_CONNECT_ETHERNET

            /* Start the server for the first time */
            server = start_webserver();
        
//-------------------- WebServer Init END -----------------------------------//

     
     
     
        gpio_set_direction(PinA, GPIO_MODE_OUTPUT);                     // setup pinModes
        gpio_set_direction(PinB, GPIO_MODE_INPUT );
        gpio_set_direction(PinC, GPIO_MODE_OUTPUT);
       
  
// ------------------- Create RTOS-Tasks ------------------------------------//
       
        xTaskCreatePinnedToCore(
                      RTOS_1,                                           // Function that implements the task.
                      "RTOS-1",                                         // Text name for the task.
                      STACK_SIZE,                                       // Stack size in bytes, not words.
                      ( void * ) 1,                                     // Parameter passed into the task.
                      tskIDLE_PRIORITY+2,
                      &xHandle1,                                        // Variable to hold the task's data structure.
                      0);
        

      
        
        
                     
        xTaskCreatePinnedToCore(
                      RTOS_2,                                           // Function that implements the task.
                      "RTOS-2",                                         // Text name for the task.
                      STACK_SIZE,                                       // Stack size in bytes, not words.
                      ( void * ) 1,                                     // Parameter passed into the task.
                      tskIDLE_PRIORITY+1,
                      &xHandle2,                                        // Variable to hold the task's data structure.
                      0);
     
     
     
        StartCore1();                                                   // Start the one and only task in core 1

        

         //esp_task_wdt_delete(TaskA);
         //esp_task_wdt_delete(xHandle2);

     
                     
        /*
        while(1) {
          vTaskDelay(10000);
        }
        */
       
    }
