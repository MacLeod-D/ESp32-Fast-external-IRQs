# fastIRQ2 
# see
# https://github.com/MacLeod-D/ESp32-Fast-external-IRQs/blob/master/README.md
